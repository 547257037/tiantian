CREATE FUNCTION upd_timestamp()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
begin
    new.update_time = current_timestamp;
    return new;
end
$$;

